<?php

    $db = new db(DB_HOST,DB_USER,DB_PASS,DB_NAME);

?>